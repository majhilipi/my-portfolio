This is my personal portfolio website built using HTML and Tailwind CSS for the DevTown Bootcamp project.

The site includes four main sections: Home, About Me, Projects, and Contact. I used Tailwind classes for layout and styling and ensured it works on all screen sizes.

I learned how to use Tailwind's grid, flex, and form components , and how to make a modern UI without writing custom CSS. This project helped me understand responsive design and semantic Html.

--Lipika Majhi.